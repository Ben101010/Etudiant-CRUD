<?php $__env->startSection("contenu"); ?>

        <div class="my-3 p-3 bg-body rounded shadow-sm">
            <h4 class="border-bottom pb-2 mb-4">Listes des Etudiants Inscrits</h4>

                <div class="mb-4">

                    <table class="table table-bordered table-hover">

                        <thead>
                        <tr>
                            <th scope="col">N°</th>
                            <th scope="col">Nom</th>
                            <th scope="col">Prenom</th>
                            <th scope="col">Classe</th>
                            <th scope="col">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                    <td><?php echo e($etudiant->nom); ?></td>
                                    <td><?php echo e($etudiant->prenom); ?></td>
                                    <td><?php echo e($etudiant->classe_id); ?></td>
                                    <td>
                                        <a href="#" class="btn btn-info">Modifier</a>
                                        <a href="#" class="btn btn-danger">Supprimer</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                         <?php echo e($etudiants->links()); ?>

                    </table>

                </div>

                <div class="d-flex mt-4">
                    <a href="#" class="btn btn-primary">Ajouter un Etudiant</a>
                </div>


        </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Laravel Boss\tuto-app\resources\views/etudiant.blade.php ENDPATH**/ ?>