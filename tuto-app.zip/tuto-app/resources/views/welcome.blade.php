



@extends("layout.index")


@section("contenu")

            <div class="my-3 p-3 bg-body rounded shadow-sm">
                <h4 class="border-bottom pb-2 mb-4">Bienvenue sur notre Application</h4>



            </div>


@endsection
